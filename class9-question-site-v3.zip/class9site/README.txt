=== LOCAL E CHALANO ===
pip install -r requirements.txt
python app.py        ->  http://localhost:5000
Test chalate: python tests.py   (27ti check, shob PASS howa uchit)

=== GIT E DEWAR AGE ===
1) config.py ba environment variable e ADMIN_PASSWORD, PAY_NUMBER bodlao.
   (admin123 rekhe publish korle keu admin hoye jabe!)
2) .gitignore ache: data.db, uploads, secret.key git e jabe na. (Nijer password/file git e dio na.)
   git init && git add . && git commit -m "first" && git push

=== PUBLISH (Render / Railway / PythonAnywhere / VPS) ===
Start command:   gunicorn app:app
Environment variables:
   ADMIN_PASSWORD = tomar shokto password
   ADMIN_PHONE    = tomar admin phone
   PAY_NUMBER     = tomar bKash/Nagad number
   SECRET_KEY     = lomba random text
   HTTPS          = 1   (https e dile)
   DATA_DIR       = persistent disk er path (na dile redeploy e data/upload mushe jete pare)
Prothombar admin account auto toiri hoy. Login kore Settings theke baki shob bodlano jay.
