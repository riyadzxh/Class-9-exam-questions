import os
# ====== ekhane nijer tottho boshan (ba environment variable e dao) ======
SITE_NAME = os.environ.get("SITE_NAME", "Class 9 Question Bank")
PAY_NUMBER = os.environ.get("PAY_NUMBER", "01XXXXXXXXX")   # tomar bKash/Nagad number
PAY_METHOD = os.environ.get("PAY_METHOD", "bKash / Nagad (Send Money)")
ADMIN_PHONE = os.environ.get("ADMIN_PHONE", "01700000000")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")  # PUBLISH er age ABOSSHO bodlao!
